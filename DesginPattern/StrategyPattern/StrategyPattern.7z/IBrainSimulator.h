#pragma once
__interface IBrainSimulator
{
	void Simulate();
};